export interface WpAnalysisResponse {
  success: boolean;
  overall_score: number;
  ai_readability: number;
  digital_authority: number;
  conversion_readiness: number;
  product_discoverability: number;
  pillars: Record<string, number>;
  ai_scores: Record<string, number>;
  sub_scores: Record<string, number>;
  phase2_sub_scores: Record<string, number>;
  crawler_signals: Record<string, any>;
  ai_readability_detail: Record<string, any>;
  digital_authority_detail: Record<string, any>;
  conversion_readiness_detail: Record<string, any>;
  product_discoverability_detail: Record<string, any>;
  recommendations: Recommendation[];
  authorship: any;
}

export interface Recommendation {
  title: string;
  description: string;
  icon: string;
  color: string;
  pillar: string;
  priority: 1 | 2 | 3;
}

export interface AuthResponse {
  apiKey: string;
  email?: string;
}
