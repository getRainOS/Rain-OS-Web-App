import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import LandingPage from "@/pages/LandingPage";
import LoadingScreen from "@/pages/LoadingScreen";
import ResultsDashboard from "@/pages/ResultsDashboard";
import Dashboard from "@/pages/Dashboard";
import DocsPage from "@/pages/DocsPage";
import PrivacyPolicyPage from "@/pages/PrivacyPolicyPage";
import TermsOfServicePage from "@/pages/TermsOfServicePage";
import { AuthModal } from "@/components/auth/AuthModal";
import RainBackground from "@/components/marketing/RainBackground";
import { analyzeContent } from "@/lib/api";
import { WpAnalysisResponse } from "@/types";

type AppState = 'landing' | 'analyzing' | 'auth_wall' | 'results' | 'dashboard';

function AppContent() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [report, setReport] = useState<WpAnalysisResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pendingAnalysis, setPendingAnalysis] = useState<{content: string, industry: string} | null>(null);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const navigate = useNavigate();

  // Check for saved session
  useEffect(() => {
    const apiKey = localStorage.getItem('rainos_api_key');
    const savedReport = sessionStorage.getItem('rainos_last_report');
    
    if (apiKey) {
      if (savedReport) {
        try {
          setReport(JSON.parse(savedReport));
          setAppState('results');
        } catch (e) {
          sessionStorage.removeItem('rainos_last_report');
          setAppState('dashboard');
        }
      } else {
        setAppState('dashboard');
      }
    }
  }, []);

  const handleAnalyzeClick = (content: string, industry: string) => {
    const apiKey = localStorage.getItem('rainos_api_key');
    
    if (!apiKey) {
      // First use intercept logic
      setPendingAnalysis({ content, industry });
      setAppState('analyzing');
      
      // Simulate loading for 3 seconds to build anticipation, then intercept
      setTimeout(() => {
        setAuthMode('signup');
        setAppState('auth_wall');
      }, 3000);
      return;
    }

    // Normal flow
    runAnalysis(content, industry, apiKey);
  };

  const runAnalysis = async (content: string, industry: string, apiKey: string) => {
    setAppState('analyzing');
    setError(null);
    
    try {
      const result = await analyzeContent(content, industry, apiKey);
      setReport(result);
      sessionStorage.setItem('rainos_last_report', JSON.stringify(result));
      setAppState('results');
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during analysis.");
      setAppState('dashboard');
    }
  };

  const handleAuthSuccess = (apiKey: string) => {
    localStorage.setItem('rainos_api_key', apiKey);
    
    if (pendingAnalysis) {
      runAnalysis(pendingAnalysis.content, pendingAnalysis.industry, apiKey);
      setPendingAnalysis(null);
    } else {
      setAppState('dashboard');
    }
  };

  const handleReset = () => {
    setReport(null);
    sessionStorage.removeItem('rainos_last_report');
    setAppState('dashboard');
  };

  const handleGoHome = () => {
    setAppState('landing');
  };

  return (
    <>
      <Routes>
        <Route path="/docs" element={<DocsPage />} />
        <Route path="/privacy" element={<PrivacyPolicyPage />} />
        <Route path="/terms" element={<TermsOfServicePage />} />
        <Route path="/" element={
          <>
            {(appState === 'landing' || appState === 'auth_wall') && (
              <>
                {error && (
                  <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-red-500/10 border border-red-500/20 text-red-500 px-4 py-2 rounded-lg text-sm font-medium backdrop-blur-md">
                    {error === 'INVALID_KEY' ? 'Invalid API Key provided.' :
                     error === 'SUBSCRIPTION_REQUIRED' ? 'Subscription required to perform this action.' :
                     error === 'LIMIT_EXCEEDED' ? 'Monthly API limit exceeded.' :
                     'Failed to analyze content. Please try again.'}
                  </div>
                )}
                <LandingPage 
                  onAnalyze={handleAnalyzeClick} 
                  onLoginClick={() => {
                    setAuthMode('signin');
                    setAppState('auth_wall');
                  }} 
                />
                
                {appState === 'auth_wall' && (
                  <AuthModal 
                    mode={authMode}
                    onClose={() => {
                      setAppState('landing');
                      setPendingAnalysis(null);
                    }}
                    onSuccess={handleAuthSuccess}
                    message={pendingAnalysis ? "Create your free account to see your results." : undefined}
                  />
                )}
              </>
            )}
            
            {appState === 'dashboard' && (
              <Dashboard onNewAnalysis={() => setAppState('landing')} onHome={handleGoHome} />
            )}

            {appState === 'analyzing' && <LoadingScreen />}
            
            {appState === 'results' && report && (
              <ResultsDashboard report={report} onReset={handleReset} onHome={handleGoHome} />
            )}
          </>
        } />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <div className="min-h-screen text-slate-50 selection:bg-rain-500/30 overflow-x-hidden font-sans relative">
        {/* Base Background Color */}
        <div className="fixed inset-0 bg-midnight z-0" />
        
        {/* Grid Pattern */}
        <div className="fixed inset-0 bg-grid-pattern bg-[size:60px_60px] opacity-[0.1] pointer-events-none z-[1]" />
        
        {/* Cinematic Aurora Blobs */}
        <div className="fixed top-[-20%] left-[-10%] w-[800px] h-[800px] bg-rain-500/5 rounded-full blur-[150px] pointer-events-none z-[2] mix-blend-screen" />
        <div className="fixed bottom-[-20%] right-[-10%] w-[800px] h-[800px] bg-purple-500/5 rounded-full blur-[150px] pointer-events-none z-[2] mix-blend-screen" />
        <div className="fixed top-[10%] right-[5%] w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none z-[2] mix-blend-screen animate-pulse" />
        
        {/* Rain Background */}
        <RainBackground />
        
        {/* Vignette & Depth */}
        <div className="fixed inset-0 bg-gradient-to-b from-midnight/40 via-transparent to-midnight pointer-events-none z-[4]" />
        <div className="fixed inset-0 bg-[radial-gradient(circle_at_50%_50%,transparent_0%,rgba(2,4,16,0.4)_100%)] pointer-events-none z-[4]" />
        
        <div className="relative z-10 flex flex-col min-h-screen">
          <AppContent />
        </div>
      </div>
    </Router>
  );
}
