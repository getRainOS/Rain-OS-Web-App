import React from 'react';
import { Link } from 'react-router-dom';

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-midnight text-slate-50 pt-32 pb-24 relative z-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-12">
          <Link to="/" className="text-rain-400 hover:text-rain-300 font-medium mb-4 inline-block">← Back to Home</Link>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Documentation</h1>
          <p className="text-xl text-slate-400">Everything you need to know to get started with rain OS.</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <div className="sticky top-32 space-y-2">
              <a href="#quick-start" className="block text-sm text-slate-400 hover:text-white transition-colors">Quick Start</a>
              <a href="#get-key" className="block text-sm text-slate-400 hover:text-white transition-colors">Get Your API Key</a>
              <a href="#connect-wp" className="block text-sm text-slate-400 hover:text-white transition-colors">Connect WordPress</a>
              <a href="#how-to-analyze" className="block text-sm text-slate-400 hover:text-white transition-colors">How to Analyze</a>
              <a href="#faq" className="block text-sm text-slate-400 hover:text-white transition-colors">FAQ & Support</a>
            </div>
          </div>
          
          <div className="lg:col-span-3 space-y-16">
            <section id="quick-start">
              <h2 className="text-2xl font-bold text-white mb-6">Quick Start Overview</h2>
              <p className="text-slate-400 leading-relaxed mb-4">Welcome to rain OS. Getting started takes less than 2 minutes.</p>
              <ol className="list-decimal list-inside space-y-4 text-slate-300">
                <li>Sign up for an account.</li>
                <li>Copy your API Key.</li>
                <li>Paste your content into the analyzer.</li>
                <li>Review your AI Readability score and apply fixes.</li>
              </ol>
            </section>
            
            <section id="get-key">
              <h2 className="text-2xl font-bold text-white mb-6">Step 1: Get Your API Key</h2>
              <div className="bg-rain-500/10 border border-rain-500/30 rounded-xl p-6 mb-6">
                <p className="text-rain-400 font-medium">Your API key is your passport to the rain OS ecosystem. Keep it secret.</p>
              </div>
              <p className="text-slate-400 leading-relaxed">You can find your API key in your dashboard after signing up. It starts with <code className="bg-white/10 px-2 py-1 rounded text-sm text-white">sk_live_</code>.</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
