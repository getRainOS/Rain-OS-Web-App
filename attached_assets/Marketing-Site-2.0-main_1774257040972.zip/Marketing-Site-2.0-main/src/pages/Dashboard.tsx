import React from 'react';
import { 
  BookOpen, 
  LayoutDashboard, 
  Activity, 
  BarChart2, 
  History, 
  Radio, 
  FileSearch, 
  FileText, 
  PlayCircle, 
  Wrench, 
  TrendingUp,
  Search,
  Bell,
  Plus,
  FileText as FileIcon,
  Target,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

const performanceData = [
  { name: 'Jan', score: 85 },
  { name: 'Feb', score: 84 },
  { name: 'Mar', score: 83 },
  { name: 'Apr', score: 84 },
  { name: 'May', score: 88 },
  { name: 'Jun', score: 90 },
  { name: 'Jul', score: 91 },
];

const pillarData = [
  { name: 'AI Readability', score: 90, color: '#22d3ee' },
  { name: 'Digital Authority', score: 78, color: '#10b981' },
  { name: 'Conversion Readiness', score: 84, color: '#a855f7' },
  { name: 'Product Discoverability', score: 72, color: '#f97316' },
];

interface DashboardProps {
  onNewAnalysis: () => void;
  onHome?: () => void;
}

export default function Dashboard({ onNewAnalysis, onHome }: DashboardProps) {
  return (
    <div className="flex h-screen bg-[#0b0f19] text-slate-300 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 flex flex-col bg-[#0b0f19] z-20">
        <div className="h-16 flex items-center px-6 border-b border-white/5 shrink-0">
          <button onClick={onHome} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <span className="text-2xl font-bold text-white tracking-tight">r<span className="text-sky-400">ai</span>n</span>
            <div className="px-2 py-0.5 rounded border border-white/10 bg-white/5 flex items-center justify-center">
              <span className="text-[10px] font-bold tracking-wider text-sky-400 uppercase">BETA</span>
            </div>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-6 custom-scrollbar">
          <div className="space-y-1">
            <NavItem icon={<BookOpen size={16} />} label="Learn About AI Readability" />
          </div>

          <div className="space-y-1">
            <NavItem icon={<LayoutDashboard size={16} />} label="AI Readability Dashboard" active />
            <div className="pl-9 space-y-1 mt-1">
              <SubNavItem label="Performance" active />
              <SubNavItem label="Pillar Breakdown" />
              <SubNavItem label="Score History" />
              <SubNavItem label="Content Signals" />
            </div>
          </div>

          <div className="space-y-1">
            <NavItem icon={<FileSearch size={16} />} label="Content Analyzer" onClick={onNewAnalysis} />
          </div>

          <div className="space-y-1">
            <NavItem icon={<FileText size={16} />} label="Documentation" />
            <div className="pl-9 space-y-1 mt-1">
              <SubNavItem label="Getting Started" />
              <SubNavItem label="Troubleshooting" />
              <SubNavItem label="Improve Your Score" />
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/5 text-xs text-slate-500 space-y-2 shrink-0">
          <a href="mailto:support@getrainos.com" className="block hover:text-white transition-colors">support@getrainos.com</a>
          <button className="text-cyan-400 hover:text-cyan-300 transition-colors">Send Feedback</button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#0b0f19]">
        {/* Header */}
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 shrink-0">
          <div>
            <h1 className="text-xl font-bold text-white font-display">Dashboard</h1>
            <p className="text-xs text-slate-400">Monitor your content performance and AI Readability metrics</p>
          </div>

          <div className="flex items-center gap-4">
            <select className="bg-[#151b2b] border border-white/10 rounded-md text-xs text-slate-300 px-3 py-1.5 focus:outline-none focus:border-cyan-500">
              <option>Last 30 Days</option>
              <option>Last 7 Days</option>
              <option>All Time</option>
            </select>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="Search content..." 
                className="bg-[#151b2b] border border-white/10 rounded-md text-xs text-slate-300 pl-9 pr-4 py-1.5 w-64 focus:outline-none focus:border-cyan-500 placeholder:text-slate-600"
              />
            </div>

            <button className="relative p-1.5 text-slate-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-[#0b0f19]"></span>
            </button>

            <Button onClick={onNewAnalysis} size="sm" className="bg-cyan-500 hover:bg-cyan-400 text-black font-medium text-xs px-4 h-8 rounded-md">
              <Plus className="w-4 h-4 mr-1" /> New Analysis
            </Button>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-6">
            
            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <KpiCard 
                icon={<FileIcon className="w-5 h-5 text-cyan-400" />}
                iconBg="bg-cyan-500/10"
                value="156"
                label="Total Analyses"
                subLabel="Last 30 Days"
                score={75}
                color="#22d3ee"
              />
              <KpiCard 
                icon={<TrendingUp className="w-5 h-5 text-emerald-400" />}
                iconBg="bg-emerald-500/10"
                value="78"
                label="Average Score"
                subLabel="Last 30 Days"
                score={78}
                color="#10b981"
              />
              <KpiCard 
                icon={<Target className="w-5 h-5 text-purple-400" />}
                iconBg="bg-purple-500/10"
                value="82%"
                label="Content Health"
                subLabel="Last 30 Days"
                score={82}
                color="#a855f7"
              />
              <KpiCard 
                icon={<Zap className="w-5 h-5 text-orange-400" />}
                iconBg="bg-orange-500/10"
                value="47%"
                label="API Usage"
                subLabel="This Billing Cycle"
                score={47}
                color="#f97316"
              />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Performance History Chart */}
              <div className="lg:col-span-2 bg-[#151b2b] border border-white/5 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-sm font-bold text-white">Performance History</h3>
                  <span className="text-xs text-slate-500 bg-white/5 px-2 py-1 rounded">Last 30 Days</span>
                </div>
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis 
                        dataKey="name" 
                        stroke="#475569" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false} 
                        dy={10}
                      />
                      <YAxis 
                        stroke="#475569" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false} 
                        domain={[70, 100]} 
                        ticks={[70, 80, 90, 100]}
                        dx={-10}
                      />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px' }}
                        itemStyle={{ color: '#22d3ee' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#22d3ee" 
                        strokeWidth={2} 
                        dot={{ r: 4, fill: '#0b0f19', stroke: '#22d3ee', strokeWidth: 2 }} 
                        activeDot={{ r: 6, fill: '#22d3ee', stroke: '#0b0f19', strokeWidth: 2 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Pillar Breakdown Chart */}
              <div className="bg-[#151b2b] border border-white/5 rounded-xl p-6 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-white">Pillar Breakdown</h3>
                  <span className="text-xs text-slate-500 bg-white/5 px-2 py-1 rounded">Last 30 Days</span>
                </div>
                
                <div className="flex items-center gap-2 mb-6">
                  <span className="text-xs font-medium text-orange-400">Product Discoverability</span>
                  <div className="w-8 h-4 bg-orange-500/20 rounded-full relative cursor-pointer flex items-center">
                    <div className="w-3 h-3 bg-orange-500 rounded-full absolute right-0.5"></div>
                  </div>
                  <span className="text-[10px] text-slate-500">Active</span>
                </div>

                <div className="flex-1 w-full min-h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={pillarData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis dataKey="name" hide />
                      <YAxis 
                        stroke="#475569" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false} 
                        domain={[50, 100]} 
                        ticks={[50, 75, 100]}
                      />
                      <Tooltip 
                        cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px' }}
                      />
                      <Bar dataKey="score" radius={[4, 4, 0, 0]} maxBarSize={40}>
                        {pillarData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}

// Subcomponents

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors text-left",
        active 
          ? "bg-[#151b2b] text-white font-medium border border-white/5" 
          : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
      )}
    >
      <span className={cn(active ? "text-cyan-400" : "text-slate-500")}>{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
}

function SubNavItem({ label, active }: { label: string, active?: boolean }) {
  return (
    <button className={cn(
      "w-full text-left px-3 py-1.5 text-xs rounded-md transition-colors",
      active ? "text-cyan-400 font-medium" : "text-slate-500 hover:text-slate-300"
    )}>
      {label}
    </button>
  );
}

function KpiCard({ icon, iconBg, value, label, subLabel, score, color }: { icon: React.ReactNode, iconBg: string, value: string, label: string, subLabel: string, score: number, color: string }) {
  const radius = 16;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="bg-[#151b2b] border border-white/5 rounded-xl p-5 flex flex-col justify-between relative overflow-hidden group hover:border-white/10 transition-colors">
      <div className="flex justify-between items-start mb-4">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", iconBg)}>
          {icon}
        </div>
        
        {/* Mini Arc Gauge */}
        <div className="relative w-10 h-10">
          <svg width="40" height="40" className="transform -rotate-90">
            <circle cx="20" cy="20" r={radius} fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="4" />
            <circle 
              cx="20" cy="20" r={radius} 
              fill="transparent" 
              stroke={color} 
              strokeWidth="4" 
              strokeDasharray={circumference} 
              strokeDashoffset={strokeDashoffset} 
              strokeLinecap="round" 
            />
          </svg>
        </div>
      </div>
      
      <div>
        <div className="text-3xl font-bold text-white font-display tracking-tight">{value}</div>
        <div className="text-sm font-medium text-slate-300 mt-1">{label}</div>
        <div className="text-xs text-slate-500 mt-1">{subLabel}</div>
      </div>
    </div>
  );
}
