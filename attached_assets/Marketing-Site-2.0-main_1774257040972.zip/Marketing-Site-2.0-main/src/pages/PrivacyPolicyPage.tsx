import React from 'react';
import { Link } from 'react-router-dom';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-midnight text-slate-50 pt-32 pb-24 relative z-10">
      <div className="max-w-4xl mx-auto px-6">
        <Link to="/" className="text-rain-400 hover:text-rain-300 font-medium mb-4 inline-block">← Back to Home</Link>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Privacy Policy</h1>
        <p className="text-slate-400 mb-12">Last updated: Dec 14, 2025</p>
        
        <div className="space-y-12 text-slate-300 leading-relaxed">
          <section id="info-collect">
            <h2 className="text-2xl font-bold text-white mb-6">1. Information We Collect</h2>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">Personal Data</h3>
            <p className="mb-4">We collect your email address when you sign up for an account.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">Usage Data</h3>
            <p className="mb-4">We collect anonymized usage data to improve our service.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">Billing Data</h3>
            <p className="mb-4">We use Stripe for payment processing. We do not store your credit card information.</p>
          </section>
          
          <section id="user-content">
            <h2 className="text-2xl font-bold text-white mb-6">2. Our Policy on User Content (Crucial)</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>Processing: We process your text to generate AI Readability scores.</li>
              <li>Non-Storage: We do not store the content you analyze.</li>
              <li>Purpose: Your content is only used to provide the service you requested.</li>
            </ul>
          </section>
          
          <section id="data-usage">
            <h2 className="text-2xl font-bold text-white mb-6">3. How We Use the Data</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>To provide and maintain our Service</li>
              <li>To notify you about changes to our Service</li>
              <li>To provide customer support</li>
              <li>To gather analysis or valuable information so that we can improve our Service</li>
              <li>To monitor the usage of our Service</li>
              <li>To detect, prevent and address technical issues</li>
            </ul>
          </section>
          
          <section id="disclosure">
            <h2 className="text-2xl font-bold text-white mb-6">4. Disclosure of Data</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>To comply with a legal obligation</li>
              <li>To protect and defend the rights or property of rain OS</li>
              <li>To prevent or investigate possible wrongdoing in connection with the Service</li>
              <li>To protect the personal safety of users of the Service or the public</li>
            </ul>
          </section>
          
          <section id="security">
            <h2 className="text-2xl font-bold text-white mb-6">5. Security of Data</h2>
            <p>The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure.</p>
          </section>
          
          <section id="rights">
            <h2 className="text-2xl font-bold text-white mb-6">6. Your Data Protection Rights</h2>
            <ul className="list-disc list-inside space-y-2 mb-4">
              <li>The right to access, update or to delete the information we have on you.</li>
              <li>The right of rectification.</li>
              <li>The right to object.</li>
              <li>The right of restriction.</li>
              <li>The right to data portability.</li>
            </ul>
            <p>Please contact us if you wish to exercise these rights.</p>
          </section>
          
          <section id="changes">
            <h2 className="text-2xl font-bold text-white mb-6">7. Changes to This Privacy Policy</h2>
            <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
          </section>
          
          <section id="contact">
            <h2 className="text-2xl font-bold text-white mb-6">8. Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:support@getrainos.com" className="text-rain-400 hover:underline">support@getrainos.com</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
