import React from 'react';
import { Link } from 'react-router-dom';

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-midnight text-slate-50 pt-32 pb-24 relative z-10">
      <div className="max-w-4xl mx-auto px-6">
        <Link to="/" className="text-rain-400 hover:text-rain-300 font-medium mb-4 inline-block">← Back to Home</Link>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Terms of Service</h1>
        <p className="text-slate-400 mb-12">Last updated: Dec 14, 2025</p>
        
        <div className="space-y-12 text-slate-300 leading-relaxed">
          <section id="desc">
            <h2 className="text-2xl font-bold text-white mb-6">1. Description of Service</h2>
            <p>rain OS provides an AI Readability analysis tool for content creators and SEO professionals. The service analyzes text to provide scores and recommendations.</p>
          </section>
          
          <section id="accounts">
            <h2 className="text-2xl font-bold text-white mb-6">2. User Accounts</h2>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">2.1 Account Responsibility</h3>
            <p className="mb-4">You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">2.2 API Key Usage</h3>
            <p className="mb-4">Your API key is personal to your account. You may not share it with others or use it in a way that violates these Terms.</p>
          </section>
          
          <section id="subscription">
            <h2 className="text-2xl font-bold text-white mb-6">3. Subscription</h2>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">3.1 Billing</h3>
            <p className="mb-4">You will be billed in advance on a recurring and periodic basis (such as monthly or annually), depending on the type of subscription plan you select.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">3.2 Analysis Actions</h3>
            <p className="mb-4">Each plan comes with a specific number of Analysis Actions per billing cycle. Unused actions do not roll over.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">3.3 Payment and Refunds</h3>
            <p className="mb-4">All payments are non-refundable except as required by law.</p>
          </section>
          
          <section id="content">
            <h2 className="text-2xl font-bold text-white mb-6">4. Content and Data Processing</h2>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">4.1 Ownership</h3>
            <p className="mb-4">You retain all your ownership rights in your Content.</p>
            <h3 className="text-lg font-bold text-white mb-2 mt-6">4.2 Non-Storage</h3>
            <p className="mb-4">We process your Content to provide the Service but do not store it permanently.</p>
          </section>
          
          <section id="acceptable">
            <h2 className="text-2xl font-bold text-white mb-6">5. Acceptable Use Policy</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>You may not use the Service for any illegal or unauthorized purpose.</li>
              <li>You must not transmit any worms or viruses or any code of a destructive nature.</li>
              <li>You must not attempt to reverse engineer or hack the Service.</li>
            </ul>
          </section>
          
          <section id="termination">
            <h2 className="text-2xl font-bold text-white mb-6">6. Termination</h2>
            <p>We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
          </section>
          
          <section id="warranty">
            <h2 className="text-2xl font-bold text-white mb-6">7. Disclaimer of Warranties</h2>
            <p>Your use of the Service is at your sole risk. The Service is provided on an "AS IS" and "AS AVAILABLE" basis.</p>
          </section>
          
          <section id="liability">
            <h2 className="text-2xl font-bold text-white mb-6">8. Limitation of Liability</h2>
            <p>In no event shall rain OS, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages.</p>
          </section>
          
          <section id="law">
            <h2 className="text-2xl font-bold text-white mb-6">9. Governing Law</h2>
            <p>These Terms shall be governed and construed in accordance with the laws of [Your State/Country], without regard to its conflict of law provisions.</p>
          </section>
          
          <section id="changes">
            <h2 className="text-2xl font-bold text-white mb-6">10. Changes</h2>
            <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
