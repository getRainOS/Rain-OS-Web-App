import React, { useEffect, useState } from 'react';

const LOADING_MESSAGES = [
  "Parsing content structure...",
  "Evaluating AI readability signals...",
  "Checking crawler accessibility...",
  "Scoring digital authority...",
  "Assessing conversion readiness...",
  "Analyzing product discoverability...",
  "Generating diagnostic signals...",
  "Ranking recommendations by impact..."
];

export default function LoadingScreen() {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % LOADING_MESSAGES.length);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background text-slate-50 relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none"></div>
      
      <div className="relative z-10 flex flex-col items-center">
        <div className="relative w-32 h-32 mb-8 flex items-center justify-center">
          {/* Outer rotating ring */}
          <svg className="absolute inset-0 w-full h-full animate-[spin_4s_linear_infinite] opacity-30" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="48" fill="none" stroke="#0ea5e9" strokeWidth="1" strokeDasharray="10 5" />
          </svg>
          
          {/* Inner pulsing ring */}
          <svg className="absolute inset-0 w-full h-full animate-[spin_3s_linear_infinite_reverse] opacity-50" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="40 20" />
          </svg>
          
          {/* Center logo */}
          <div className="flex items-center justify-center gap-2 animate-pulse">
            <span className="text-4xl font-bold text-white tracking-tight">r<span className="text-sky-400">ai</span>n</span>
            <div className="px-2 py-0.5 rounded border border-white/10 bg-white/5 flex items-center justify-center">
              <span className="text-[10px] font-bold tracking-wider text-sky-400 uppercase">BETA</span>
            </div>
          </div>
        </div>
        
        <h2 className="text-xl font-display font-medium text-white mb-2 animate-in fade-in slide-in-from-bottom-2 text-glow">
          Analyzing Content
        </h2>
        
        <div className="h-6 overflow-hidden relative w-64 text-center">
          <p 
            key={messageIndex} 
            className="text-sm text-slate-400 font-mono animate-in slide-in-from-bottom-full fade-in duration-300"
          >
            {LOADING_MESSAGES[messageIndex]}
          </p>
        </div>
        
        <div className="w-48 h-1 bg-white/5 rounded-full mt-6 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-primary via-accent to-blue-500 w-1/2 rounded-full animate-[slide_2s_ease-in-out_infinite_alternate]" />
        </div>
      </div>
    </div>
  );
}
