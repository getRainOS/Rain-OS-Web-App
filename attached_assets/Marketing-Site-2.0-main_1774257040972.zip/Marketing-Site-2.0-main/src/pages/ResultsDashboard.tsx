import React, { useState } from 'react';
import { WpAnalysisResponse } from '@/types';
import { ScoreGauge } from '@/components/analyzer/ScoreGauge';
import { PillarCard } from '@/components/analyzer/PillarCard';
import { DiagnosticCard } from '@/components/analyzer/DiagnosticCard';
import { Button } from '@/components/ui/button';
import { RefreshCw, FileText, ChevronRight, AlertCircle, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ResultsDashboardProps {
  report: WpAnalysisResponse;
  onReset: () => void;
  onHome?: () => void;
}

type Tab = 'overview' | 'p1' | 'p2' | 'p3' | 'p4' | 'diagnostics' | 'recommendations';

export default function ResultsDashboard({ report, onReset, onHome }: ResultsDashboardProps) {
  const [activeTab, setActiveTab] = useState<Tab>('overview');

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'p1', label: 'AI Readability', color: '#22d3ee' },
    { id: 'p2', label: 'Digital Authority', color: '#10b981' },
    { id: 'p3', label: 'Conversion Readiness', color: '#a855f7' },
    { id: 'p4', label: 'Product Discoverability', color: '#f97316' },
    { id: 'diagnostics', label: 'Diagnostics' },
    { id: 'recommendations', label: 'Recommendations' },
  ];

  const getOverallColor = (score: number) => {
    if (score >= 80) return '#10b981';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
  };

  const renderOverview = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-4 lg:col-span-3 card-surface p-8 flex flex-col items-center justify-center text-center">
          <ScoreGauge score={report.overall_score} color={getOverallColor(report.overall_score)} size={240} />
          <div className="mt-8 space-y-2">
            <div className={cn("inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border", 
              report.overall_score >= 80 ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" :
              report.overall_score >= 60 ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
              "bg-red-500/10 text-red-500 border-red-500/20"
            )}>
              {report.overall_score >= 80 ? "Strong" : report.overall_score >= 60 ? "Needs Work" : "Critical Issues"}
            </div>
            <p className="text-xs text-slate-500 max-w-[200px] mx-auto leading-relaxed">
              Based on 4 pillars and 14 diagnostic signals.
            </p>
          </div>
        </div>

        <div className="md:col-span-8 lg:col-span-9 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <PillarCard 
            title="AI Readability" 
            score={report.ai_readability} 
            color="#22d3ee" 
            subScores={{ 'Semantic Clarity': report.sub_scores.semanticClarity, 'Readability Score': report.sub_scores.readabilityScore }}
            crawlerSignal={{ label: 'AI Crawler', status: report.crawler_signals.ai_crawler_access }}
            onClick={() => setActiveTab('p1')}
          />
          <PillarCard 
            title="Digital Authority" 
            score={report.digital_authority} 
            color="#10b981" 
            subScores={{ 'Entity Recognition': report.sub_scores.entityRecognition, 'Citation Readiness': report.sub_scores.citationReadiness }}
            crawlerSignal={{ label: 'llms.txt', status: report.crawler_signals.llms_txt_status }}
            onClick={() => setActiveTab('p2')}
          />
          <PillarCard 
            title="Conversion Readiness" 
            score={report.conversion_readiness} 
            color="#a855f7" 
            subScores={{ 'Schema Extraction': report.sub_scores.schemaExtraction, 'QA Format': report.sub_scores.qaFormatDetection }}
            crawlerSignal={{ label: 'Conversion Risk', status: report.crawler_signals.crawler_conversion_risk }}
            onClick={() => setActiveTab('p3')}
          />
          <PillarCard 
            title="Product Discoverability" 
            score={report.product_discoverability} 
            color="#f97316" 
            subScores={{ 'Schema Completeness': report.crawler_signals.schema_completeness, 'Answer Layer': report.product_discoverability_detail.answer_layer_quality }}
            crawlerSignal={{ label: 'AI Crawler', status: report.crawler_signals.p4_ai_crawler_permissions }}
            onClick={() => setActiveTab('p4')}
          />
        </div>
      </div>

      {report.recommendations.length > 0 && (
        <div className="card-surface p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-display font-medium text-white">Top Recommendations</h3>
            <Button variant="link" className="text-slate-400 hover:text-white" onClick={() => setActiveTab('recommendations')}>
              View All {report.recommendations.length} <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {report.recommendations.slice(0, 3).map((rec, i) => (
              <div key={i} className="bg-white/5 border border-white/5 rounded-lg p-4 hover:bg-white/10 transition-colors cursor-pointer" onClick={() => setActiveTab('recommendations')}>
                <div className="flex items-center gap-2 mb-3">
                  <span className={cn("text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border", 
                    rec.priority === 1 ? "bg-red-500/10 text-red-500 border-red-500/20" :
                    rec.priority === 2 ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
                    "bg-blue-500/10 text-blue-500 border-blue-500/20"
                  )}>
                    {rec.priority === 1 ? 'CRITICAL' : rec.priority === 2 ? 'HIGH' : 'MEDIUM'}
                  </span>
                  <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded border border-white/10" style={{ color: rec.color }}>
                    {rec.pillar}
                  </span>
                </div>
                <h4 className="text-sm font-medium text-slate-200 mb-1 leading-tight flex items-start gap-2">
                  <span className="mt-0.5">{rec.icon}</span> {rec.title}
                </h4>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{rec.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderDiagnostics = () => {
    const signals = Object.entries(report.phase2_sub_scores).map(([key, val]) => {
      let priority: 1 | 2 | 3 | undefined = undefined;
      if (key === 'retrieval_answerability' && val < 60) priority = 1;
      else if (['visual_to_html_redundancy_flag', 'faq_structure_quality', 'brand_mention_density', 'social_proof_markup', 'product_variant_coverage', 'merchant_identity_clarity'].includes(key) && val < 50) priority = 2;
      else if (key === 'brand_mention_density' && val < 40) priority = 2;
      else if (['substitution_compatibility_signals', 'semantic_redundancy_score'].includes(key) && val < 50) priority = 3;
      
      return { signal: key, score: val, priority, description: "Diagnostic signal evaluation." };
    });

    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="card-surface p-6 border-l-4 border-l-blue-500">
          <h3 className="text-lg font-display font-medium text-white mb-2">Phase 2 Diagnostic Signals</h3>
          <p className="text-sm text-slate-400 max-w-3xl leading-relaxed">
            These 14 signals surface the *why* behind your score. They inform recommendations but do not affect your overall score directly.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {signals.map((s, i) => (
            <DiagnosticCard key={i} signal={s.signal} score={s.score} priority={s.priority} description={s.description} />
          ))}
        </div>
      </div>
    );
  };

  const renderRecommendations = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-display font-medium text-white">Actionable Fixes ({report.recommendations.length})</h3>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {report.recommendations.map((rec, i) => (
          <div key={i} className="card-surface p-6 flex flex-col gap-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className={cn("text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border", 
                  rec.priority === 1 ? "bg-red-500/10 text-red-500 border-red-500/20" :
                  rec.priority === 2 ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
                  "bg-blue-500/10 text-blue-500 border-blue-500/20"
                )}>
                  {rec.priority === 1 ? 'CRITICAL' : rec.priority === 2 ? 'HIGH' : 'MEDIUM'}
                </span>
                <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded border border-white/10" style={{ color: rec.color }}>
                  {rec.pillar}
                </span>
              </div>
            </div>
            <div>
              <h4 className="text-base font-medium text-slate-200 mb-2 flex items-start gap-2">
                <span className="mt-0.5">{rec.icon}</span> {rec.title}
              </h4>
              <p className="text-sm text-slate-400 leading-relaxed">{rec.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderPillarDetail = (id: string, title: string, color: string, detailKey: keyof WpAnalysisResponse) => {
    const details = report[detailKey] as Record<string, any>;
    const score = report.pillars[id.replace('p', '') === '1' ? 'ai_readability' : id.replace('p', '') === '2' ? 'digital_authority' : id.replace('p', '') === '3' ? 'conversion_readiness' : 'product_discoverability'];
    
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="card-surface p-8 flex flex-col md:flex-row items-center gap-8 border-t-4" style={{ borderTopColor: color }}>
          <ScoreGauge score={score} color={color} size={160} label={`${title.toUpperCase()} SCORE`} />
          <div className="flex-1 space-y-4 text-center md:text-left">
            <h2 className="text-3xl font-display font-bold text-white">{title}</h2>
            <p className="text-slate-400 leading-relaxed max-w-2xl">
              {id === 'p1' ? "Can AI systems parse and understand this content without ambiguity?" :
               id === 'p2' ? "Should AI systems trust this content enough to cite it?" :
               id === 'p3' ? "Is this content structured for AI extraction and action-triggering?" :
               "Can AI systems discover, understand, and surface this content in product contexts?"}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(details).filter(([k]) => !k.includes('crawler') && !k.includes('llms')).map(([key, val]) => (
            <div key={key} className="card-surface p-5">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-sm font-medium text-slate-300 capitalize">{key.replace(/_/g, ' ')}</h4>
                <span className="font-mono text-sm" style={{ color }}>{val}</span>
              </div>
              <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${val}%`, backgroundColor: color }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background text-slate-50 flex flex-col selection:bg-primary/30">
      <header className="border-b border-white/5 glass-nav sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6 max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <button onClick={onHome} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <span className="text-2xl font-bold text-white tracking-tight">r<span className="text-sky-400">ai</span>n</span>
              <div className="px-2 py-0.5 rounded border border-white/10 bg-white/5 flex items-center justify-center hidden sm:flex">
                <span className="text-[10px] font-bold tracking-wider text-sky-400 uppercase">BETA</span>
              </div>
            </button>
            <div className="h-6 w-px bg-white/10 mx-2 hidden md:block"></div>
            <div className="hidden md:flex items-center gap-2 text-sm font-mono text-slate-400">
              Score: <span className="text-white font-bold">{report.overall_score}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={onReset} className="border-white/10 bg-white/5 hover:bg-white/10 text-slate-300">
              <FileText className="w-4 h-4 mr-2" /> New Content
            </Button>
            <Button size="sm" className="bg-primary hover:bg-accent text-white shadow-[0_0_15px_rgba(14,165,233,0.3)]">
              <RefreshCw className="w-4 h-4 mr-2" /> Re-analyze
            </Button>
          </div>
        </div>
        
        {/* Tabs Navigation */}
        <div className="container px-4 md:px-6 max-w-7xl mx-auto overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-6 border-b border-transparent">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Tab)}
                className={cn(
                  "py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors",
                  activeTab === tab.id 
                    ? "border-white text-white" 
                    : "border-transparent text-slate-500 hover:text-slate-300"
                )}
                style={activeTab === tab.id && tab.color ? { borderBottomColor: tab.color, color: tab.color } : {}}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 md:px-6 py-8 max-w-7xl mx-auto">
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'p1' && renderPillarDetail('p1', 'AI Readability', '#22d3ee', 'ai_readability_detail')}
        {activeTab === 'p2' && renderPillarDetail('p2', 'Digital Authority', '#10b981', 'digital_authority_detail')}
        {activeTab === 'p3' && renderPillarDetail('p3', 'Conversion Readiness', '#a855f7', 'conversion_readiness_detail')}
        {activeTab === 'p4' && renderPillarDetail('p4', 'Product Discoverability', '#f97316', 'product_discoverability_detail')}
        {activeTab === 'diagnostics' && renderDiagnostics()}
        {activeTab === 'recommendations' && renderRecommendations()}
      </main>
    </div>
  );
}
