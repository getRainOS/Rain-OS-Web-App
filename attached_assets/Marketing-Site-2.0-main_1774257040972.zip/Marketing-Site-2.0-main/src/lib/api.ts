import { WpAnalysisResponse, AuthResponse } from '@/types';

const BASE_URL = 'https://api.getrainos.com';

export const login = async (email: string, password: string): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!response.ok) throw new Error('Invalid credentials');
    return response.json();
  } catch (e) {
    // Fallback for demo purposes
    return new Promise(resolve => setTimeout(() => resolve({ apiKey: 'demo', email }), 1000));
  }
};

export const signup = async (email: string, password: string): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${BASE_URL}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!response.ok) throw new Error('Signup failed');
    return response.json();
  } catch (e) {
    // Fallback for demo purposes
    return new Promise(resolve => setTimeout(() => resolve({ apiKey: 'demo', email }), 1000));
  }
};

export const analyzeContent = async (content: string, industry: string, apiKey: string): Promise<WpAnalysisResponse> => {
  if (apiKey === 'demo') {
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockResponse), 3000);
    });
  }

  const response = await fetch(`${BASE_URL}/api/analyze`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({ action: 'full_analysis', content, industry })
  });
  
  if (response.status === 401) throw new Error('INVALID_KEY');
  if (response.status === 402) throw new Error('SUBSCRIPTION_REQUIRED');
  if (response.status === 429) throw new Error('LIMIT_EXCEEDED');
  if (!response.ok) throw new Error('API_ERROR');
  
  return response.json();
};

const mockResponse: WpAnalysisResponse = {
  "success": true,
  "overall_score": 78,
  "ai_readability": 82,
  "digital_authority": 71,
  "conversion_readiness": 80,
  "product_discoverability": 74,
  "pillars": {
    "ai_readability": 82,
    "digital_authority": 71,
    "conversion_readiness": 80,
    "product_discoverability": 74
  },
  "ai_scores": {
    "readability": 85,
    "structure": 79,
    "freshness": 66,
    "citation": 72,
    "visibility": 68
  },
  "sub_scores": {
    "semanticClarity": 88,
    "readabilityScore": 85,
    "logicalStructure": 79,
    "aeoAlignment": 81,
    "sectionConceptIsolation": 76,
    "entityRecognition": 74,
    "citationReadiness": 70,
    "descriptiveMetadata": 69,
    "socialProofMarkup": 65,
    "schemaExtraction": 72,
    "qaFormatDetection": 84,
    "metadataAudit": 78
  },
  "phase2_sub_scores": {
    "content_chunking_quality": 77,
    "information_gain_score": 68,
    "js_dependency_flag": 100,
    "entity_consistency": 82,
    "meta_description_aeo_quality": 65,
    "product_content_connection": 71,
    "visual_to_html_redundancy_flag": 55,
    "faq_structure_quality": 48,
    "answer_chunk_length": 73,
    "brand_mention_density": 38,
    "substitution_compatibility_signals": 44,
    "instruction_determinism": 79,
    "retrieval_answerability": 55,
    "semantic_redundancy_score": 62
  },
  "crawler_signals": {
    "ai_crawler_access": "open",
    "ai_crawler_access_score": 90,
    "llms_txt_status": "missing",
    "llms_txt_permissions": 0,
    "crawler_conversion_risk": "low",
    "crawler_conversion_score": 85,
    "schema_completeness": 72,
    "schema_maturity_level": "basic",
    "p4_llms_txt_status": "missing",
    "p4_llms_txt_permissions": 0,
    "p4_ai_crawler_permissions": "open",
    "p4_ai_crawler_access_score": 90
  },
  "ai_readability_detail": {
    "semantic_clarity": 88,
    "readability_score": 85,
    "logical_structure": 79,
    "aeo_alignment": 81,
    "section_concept_isolation": 76,
    "ai_crawler_access": "open",
    "ai_crawler_access_score": 90
  },
  "digital_authority_detail": {
    "entity_recognition": 74,
    "citation_readiness": 70,
    "descriptive_metadata": 69,
    "social_proof_markup": 65,
    "llms_txt_status": "missing",
    "llms_txt_permissions": 0
  },
  "conversion_readiness_detail": {
    "schema_extraction": 72,
    "qa_format_detection": 84,
    "metadata_audit": 78,
    "crawler_conversion_risk": "low",
    "crawler_conversion_score": 85
  },
  "product_discoverability_detail": {
    "schema_completeness": 72,
    "answer_layer_quality": 68,
    "entity_disambiguation": 74,
    "conversational_query_match": 71,
    "semantic_quality_score": 80,
    "attribute_completeness": 65,
    "price_availability_clarity": 58,
    "structured_content_quality": 73,
    "direct_answer_readiness": 77,
    "freshness_signals": 66,
    "product_variant_coverage": 45,
    "merchant_identity_clarity": 52
  },
  "recommendations": [
    {
      "title": "Add FAQ Schema Markup",
      "description": "Wrap your Q&A pairs in FAQPage schema to make them directly extractable by AI systems. This is the single highest-impact change you can make.",
      "icon": "📋",
      "color": "#a855f7",
      "pillar": "Conversion Readiness",
      "priority": 1
    },
    {
      "title": "Improve Brand Mention Density",
      "description": "Your brand is rarely mentioned in the body copy. Weave your brand name into explanations and how-tos to build entity association.",
      "icon": "🏷️",
      "color": "#10b981",
      "pillar": "Digital Authority",
      "priority": 2
    },
    {
      "title": "Fix Retrieval Answerability",
      "description": "Content raises questions in headings but fails to fully answer them in the body. Ensure every heading promise is fulfilled.",
      "icon": "⚠️",
      "color": "#22d3ee",
      "pillar": "AI Readability",
      "priority": 1
    }
  ],
  "authorship": {}
};
