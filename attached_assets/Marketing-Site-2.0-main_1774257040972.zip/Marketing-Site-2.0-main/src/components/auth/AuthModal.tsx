import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { login, signup } from '@/lib/api';
import { X } from 'lucide-react';

interface AuthModalProps {
  mode: 'signin' | 'signup';
  onClose: () => void;
  onSuccess: (apiKey: string) => void;
  message?: string;
}

export function AuthModal({ mode: initialMode, onClose, onSuccess, message }: AuthModalProps) {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const res = mode === 'signin' 
        ? await login(email, password)
        : await signup(email, password);
      
      onSuccess(res.apiKey);
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md card-surface p-8 shadow-2xl shadow-black/50 animate-in zoom-in-95 duration-200">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-6">
            <span className="text-3xl font-bold text-white tracking-tight">r<span className="text-sky-400">ai</span>n</span>
            <div className="px-2 py-0.5 rounded border border-white/10 bg-white/5 flex items-center justify-center">
              <span className="text-[10px] font-bold tracking-wider text-sky-400 uppercase">BETA</span>
            </div>
          </div>
          <h2 className="text-2xl font-display font-bold text-white mb-2">
            {mode === 'signin' ? 'Welcome back' : 'Create your account'}
          </h2>
          <p className="text-sm text-slate-400">
            {message || (mode === 'signin' 
              ? 'Sign in to view your analysis history and results.' 
              : 'Sign up to see your results and save your history.')}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-sm text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-2.5 text-slate-200 focus:outline-none focus:border-primary transition-colors"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-2.5 text-slate-200 focus:outline-none focus:border-primary transition-colors"
              required
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-primary hover:bg-accent text-white py-6 mt-2 shadow-[0_0_15px_rgba(14,165,233,0.3)]"
            disabled={loading}
          >
            {loading ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-slate-500">
          {mode === 'signin' ? (
            <p>Don't have an account? <button onClick={() => setMode('signup')} className="text-primary hover:text-accent font-medium">Sign up</button></p>
          ) : (
            <p>Already have an account? <button onClick={() => setMode('signin')} className="text-primary hover:text-accent font-medium">Sign in</button></p>
          )}
        </div>
      </div>
    </div>
  );
}
