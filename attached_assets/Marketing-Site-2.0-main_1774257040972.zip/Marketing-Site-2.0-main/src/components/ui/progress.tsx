import * as React from "react";
import { cn } from "@/lib/utils";

// Since we don't have radix-ui installed, I'll implement a simple Progress component
// using standard HTML/CSS for now to avoid extra deps.

const Progress = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { value?: number }
>(({ className, value, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "relative h-2 w-full overflow-hidden rounded-full bg-zinc-900",
      className
    )}
    {...props}
  >
    <div
      className="h-full w-full flex-1 bg-zinc-50 transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </div>
));
Progress.displayName = "Progress"; // ProgressPrimitive.Root.displayName;

export { Progress };
