import React from 'react';
import { cn } from '@/lib/utils';
import { ArrowRight } from 'lucide-react';

interface PillarCardProps {
  key?: string | number;
  title: string;
  score: number;
  color: string;
  subScores: Record<string, number>;
  crawlerSignal: { label: string; status: string };
  onClick: () => void;
}

export function PillarCard({ title, score, color, subScores, crawlerSignal, onClick }: PillarCardProps) {
  let statusText = "Critical";
  if (score >= 80) statusText = "Strong";
  else if (score >= 60) statusText = "Needs Work";

  // Get top 2 subscores to display
  const topSubScores = Object.entries(subScores).slice(0, 2);

  return (
    <div className="card-surface p-6 flex flex-col h-full transition-all hover:border-white/10 group cursor-pointer" onClick={onClick}>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-sm font-mono text-slate-400 uppercase tracking-wider mb-1">{title}</h3>
          <div className="flex items-center gap-2">
            <span className="text-3xl font-display font-bold text-white">{score}</span>
            <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ backgroundColor: `${color}15`, color }}>
              {statusText}
            </span>
          </div>
        </div>
        <div className="relative w-12 h-12">
          <svg width="48" height="48" className="transform -rotate-90">
            <circle cx="24" cy="24" r="20" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="4" />
            <circle cx="24" cy="24" r="20" fill="transparent" stroke={color} strokeWidth="4" 
              strokeDasharray={2 * Math.PI * 20} 
              strokeDashoffset={(2 * Math.PI * 20) - (score / 100) * (2 * Math.PI * 20)} 
              strokeLinecap="round" 
            />
          </svg>
        </div>
      </div>

      <div className="space-y-3 flex-1">
        {topSubScores.map(([key, val]) => (
          <div key={key} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 truncate pr-2">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
              <span className="font-mono text-slate-300">{val}</span>
            </div>
            <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${val}%`, backgroundColor: color }} />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={cn("w-2 h-2 rounded-full", 
            crawlerSignal.status === 'open' || crawlerSignal.status === 'none' ? 'bg-emerald-500' : 
            crawlerSignal.status === 'blocked' || crawlerSignal.status === 'high' ? 'bg-red-500' : 'bg-amber-500'
          )} />
          <span className="text-xs text-slate-400">{crawlerSignal.label}: <span className="text-slate-300 capitalize">{crawlerSignal.status}</span></span>
        </div>
        <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
      </div>
    </div>
  );
}
