import React from 'react';
import { cn } from '@/lib/utils';

interface DiagnosticCardProps {
  key?: string | number;
  signal: string;
  score: number;
  description: string;
  priority?: 1 | 2 | 3;
}

export function DiagnosticCard({ signal, score, description, priority }: DiagnosticCardProps) {
  const isGood = !priority;
  
  let badgeColor = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
  let badgeText = "GOOD";
  
  if (priority === 1) {
    badgeColor = "bg-red-500/10 text-red-500 border-red-500/20";
    badgeText = "CRITICAL";
  } else if (priority === 2) {
    badgeColor = "bg-amber-500/10 text-amber-500 border-amber-500/20";
    badgeText = "HIGH";
  } else if (priority === 3) {
    badgeColor = "bg-blue-500/10 text-blue-500 border-blue-500/20";
    badgeText = "MEDIUM";
  }

  const formattedSignal = signal.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

  return (
    <div className="card-surface p-4 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <h4 className="text-sm font-medium text-slate-200 leading-tight">{formattedSignal}</h4>
        <span className={cn("text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border whitespace-nowrap", badgeColor)}>
          {badgeText}
        </span>
      </div>
      
      <div className="flex items-center gap-3">
        <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
          <div 
            className={cn("h-full rounded-full transition-all", isGood ? "bg-emerald-500" : priority === 1 ? "bg-red-500" : priority === 2 ? "bg-amber-500" : "bg-blue-500")}
            style={{ width: `${score}%` }}
          />
        </div>
        <span className="text-xs font-mono text-slate-400 w-8 text-right">{score}</span>
      </div>
      
      {description && (
        <p className="text-xs text-slate-500 leading-relaxed mt-1">
          {description}
        </p>
      )}
    </div>
  );
}
